# Backend Development Fundamentals – Course Labs

One repository for the whole course, one folder per lab.

| Folder | Lab |
|--------|-----|
| [lab-03/](lab-03/) | REST API, query parameters, validation, debugging |

Each lab folder has its own `README.md` with run instructions.
